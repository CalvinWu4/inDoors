const misdirectArray = [
    {'WB Games': 'Warner Bros.'},
    {'Block': 'Block-EI'}
  ]
  